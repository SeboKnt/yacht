apk update
apk add nano
apk add htop
apk add lsblk
#apk add bash

#setup-desktop gnome
#setup-user
apk del gnome-apps-core
apk del firefox
apk add chromium
#apk add remmina #(lieber xfreerdp)

# remove /home
