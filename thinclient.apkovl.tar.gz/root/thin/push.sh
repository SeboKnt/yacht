# push rm -r /root/.ash_history zu server

scp -r thinclient.apkovl.tar.gz root@pxe.camp:/srv/www/
