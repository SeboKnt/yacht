apk update
apk add nano
apk add htop
apk add lsblk


# remove /home
