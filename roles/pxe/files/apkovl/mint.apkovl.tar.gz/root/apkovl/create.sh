# creates the apkovl
# home, root and etc are persistent

rm -r /root/.ash_history
lbu include /home
lbu include /root
lbu package thinclient.apkovl.tar.gz
